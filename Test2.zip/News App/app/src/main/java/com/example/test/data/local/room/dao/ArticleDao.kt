package com.example.test.data.local.room.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.test.data.local.room.entity.ArticleEntity
import kotlinx.coroutines.flow.Flow

// аннотация пишутся везде, чтобы библиотека рум понимала что это за функции и классы
@Dao
interface ArticleDao {

    @Insert //для записи данных
    fun insertArticle(article : ArticleEntity)

    @Query("SELECT * FROM article_info") //для считывания данных. В скобочках указываются запросы SQL для базы данных
    fun getArticles() : Flow<List<ArticleEntity>>
}