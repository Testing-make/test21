package com.example.test.presenter.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.test.data.local.room.entity.ArticleEntity
import com.example.test.data.remote.data.Article
import com.example.test.databinding.ItemLargeImageArticleBinding
import com.example.test.databinding.ItemSmallArticleBinding


import com.example.test.app.App.Companion.context
import com.example.test.data.local.room.MyDataBase

class ArticleAdapter : ListAdapter<Article, RecyclerView.ViewHolder>(Comparator()) {
    companion object {
        private const val VIEW_TYPE_SMALL = 0
        private const val VIEW_TYPE_LARGE = 1
    }

    private var onItemOnclickListener: (() -> Unit)? = null
    fun setItemOnClick(block: () -> Unit) {
        onItemOnclickListener = block
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_LARGE -> {
                val binding = ItemLargeImageArticleBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                LargeArticleViewHolder(binding)
            }

            else -> {
                val binding = ItemSmallArticleBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                SmallArticleViewHolder(binding)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val article = getItem(position)
        when (holder) {
            is LargeArticleViewHolder -> holder.bind(article)
            is SmallArticleViewHolder -> holder.bind(article)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if ((position) % 5 == 0) VIEW_TYPE_LARGE else VIEW_TYPE_SMALL
    }


    inner class SmallArticleViewHolder(private val binding: ItemSmallArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(article: Article) {
            Glide.with(binding.root).load(article.urlToImage).into(binding.imageNews)
            binding.textTitle.text = article.title
            binding.textSourceName.text = article.source.name
            binding.textPublishedDate.text = article.publishedAt
            itemView.setOnClickListener {
                onItemOnclickListener?.invoke()
            }
        }
    }

    inner class LargeArticleViewHolder(private val binding: ItemLargeImageArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(article: Article) {
            Glide.with(binding.root).load(article.urlToImage).into(binding.imageNews)
            binding.textTitle.text = article.title
            binding.textSourceName.text = article.source.name
            binding.textPublishedDate.text = article.publishedAt
            val db =  MyDataBase.getDb(context)
            binding.button.setOnClickListener{
                Log.d("BTN CLICK", db.toString())
                val articleInfo = ArticleEntity(title =  article.title, siteName =  article.source.name, date =  article.publishedAt)
                Log.d("BTN CLICK", articleInfo.toString())
                Thread{
                    db.getArticleDao().insertArticle(articleInfo)
                }.start()
            }
            itemView.setOnClickListener {
//                onItemOnclickListener?.invoke()
            }
        }
    }
    class Comparator : DiffUtil.ItemCallback<Article>() {
        override fun areItemsTheSame(oldItem: Article, newItem: Article): Boolean {
            return oldItem.title == newItem.title
        }

        override fun areContentsTheSame(oldItem: Article, newItem: Article): Boolean {
            return oldItem == newItem
        }
    }
}