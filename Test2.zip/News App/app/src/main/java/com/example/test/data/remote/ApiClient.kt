package com.example.test.data.remote

import com.chuckerteam.chucker.api.ChuckerInterceptor
import com.example.test.app.App
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {

    private val myClient = OkHttpClient.Builder()
        .addInterceptor(ChuckerInterceptor.Builder(App.context).build())
        .build()

    private val retrofit = Retrofit.Builder()
        .client(myClient)
        .baseUrl("https://newsapi.org")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    fun mainApi() :  MainApi = retrofit.create(MainApi::class.java)
}