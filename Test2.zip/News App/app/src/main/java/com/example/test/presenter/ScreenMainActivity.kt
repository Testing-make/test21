package com.example.test.presenter

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.asLiveData
import com.example.test.R
import com.example.test.data.local.room.MyDataBase
import com.example.test.databinding.ScreenMainBinding


class ScreenMainActivity: AppCompatActivity()  {
//    lateinit var binding: ScreenMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding = ScreenMainBinding.inflate(layoutInflater)
        setContentView(R.layout.screen_main)

        val db = MyDataBase.getDb(this)
        val txtview = findViewById<TextView>(R.id.textView2)

        //без этого кода база данных в разделе Database inspector будет подписана как closed и внутрь зайти нельзя будет
        db.getArticleDao().getArticles().asLiveData().observe(this){
            txtview.text = ""
            it.forEach{article ->
                val text = "ID: ${article.id}, date: ${article.date}, title: ${article.title}, siteName: ${article.siteName}\n"
                txtview.append(text)
            }
        }
    }
}