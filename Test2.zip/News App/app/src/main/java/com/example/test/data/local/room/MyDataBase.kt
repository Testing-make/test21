package com.example.test.data.local.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.test.data.local.room.dao.ArticleDao
import com.example.test.data.local.room.entity.ArticleEntity

@Database(entities = [ArticleEntity::class], version = 1)
abstract class MyDataBase : RoomDatabase() {

    companion object{
        fun getDb(context: Context): MyDataBase{
            return Room.databaseBuilder(context.applicationContext, MyDataBase::class.java, "MyDataBase.db")
                    .build()
        }
    }

    abstract fun getArticleDao(): ArticleDao
}