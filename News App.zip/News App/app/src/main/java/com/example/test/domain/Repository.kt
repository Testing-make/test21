package com.example.test.domain

import com.example.test.R
import com.example.test.app.App
import com.example.test.data.remote.ApiClient
import com.example.test.data.remote.data.Article
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

object Repository  {
    private val mainApi = ApiClient.mainApi()

    suspend fun getArticles(lang: String): Flow<List<Article>> {
        return flow {
            val response = mainApi.getArticles(App.context.getString(R.string.apiKey),lang,"man")
            emit(response.articles)
        }.catch { e ->
            e.printStackTrace()
            emit(emptyList())
        }.flowOn(Dispatchers.IO)
    }
}