package com.example.test.data.remote.data

data class Source(
    val id: String,
    val name: String
)