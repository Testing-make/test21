package com.example.test.presenter

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.test.R
import com.example.test.databinding.ActivityMainBinding
import com.example.test.domain.Repository
import com.example.test.presenter.adapter.ArticleAdapter
import kotlinx.coroutines.runBlocking

class MainActivity : AppCompatActivity() {
    lateinit var bindingMain: ActivityMainBinding
    var lang : String = "ru"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindingMain = ActivityMainBinding.inflate(layoutInflater)
        val button = findViewById<Button>(R.id.btn2)
        val button3 = findViewById<Button>(R.id.button2)
        val button4 = findViewById<Button>(R.id.button34)

        button.setOnClickListener {
            Log.d("btn2", "Start")
            val intent = Intent(this, ScreenMainActivity::class.java)
            Log.d("btn2", "continue")
            startActivity(intent)
            Log.d("btn2", "finish")
        }

        button3.setOnClickListener{
            lang = if (lang == "ru") "en" else "ru"
        }

        val rv: RecyclerView = findViewById(R.id.rvArticles)
        val adapter = ArticleAdapter()
        button4.setOnClickListener{
            rv.adapter = adapter
            runBlocking {
                Repository.getArticles(lang).collect { articles ->
                    Log.d("TTT", articles.toString())
                    adapter.submitList(articles)
                }
            }
        }
    }
}
