package com.example.test.data.local.room.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "article_info")
data class ArticleEntity(
    @PrimaryKey(autoGenerate = true)
    val id : Int,
    val title : String
)
