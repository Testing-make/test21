package com.example.test.presenter.ui;

public class Test {
    public static void main(String[] args) {
        System.out.print('a' == 97);
        int a = 2;
    }
}
