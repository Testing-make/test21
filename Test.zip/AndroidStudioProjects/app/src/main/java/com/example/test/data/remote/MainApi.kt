package com.example.test.data.remote

import com.example.test.data.remote.data.Articles
import retrofit2.http.GET
import retrofit2.http.Query

interface MainApi {
    @GET("/v2/everything")
    suspend fun getArticles(
        @Query("apiKey") apiKey: String,
        @Query("language") language: String,
        @Query("q") query: String,
    ): Articles
}