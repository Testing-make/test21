package com.example.test.presenter

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.test.R
import com.example.test.data.local.room.MyDataBase
import com.example.test.domain.Repository
import com.example.test.presenter.adapter.ArticleAdapter
import kotlinx.coroutines.runBlocking

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val rv: RecyclerView = findViewById(R.id.rvArticles)

        val adapter = ArticleAdapter()
        rv.adapter = adapter
        runBlocking {
            Repository.getArticles().collect { articles ->
                Log.d("TTT", articles.toString())
                adapter.submitList(articles)
            }
        }
        val myDataBase = MyDataBase().getArticleDao()
    }
}
