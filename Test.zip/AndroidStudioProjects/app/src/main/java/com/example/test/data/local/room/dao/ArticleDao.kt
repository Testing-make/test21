package com.example.test.data.local.room.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.test.data.local.room.entity.ArticleEntity

@Dao
interface ArticleDao {

    @Insert
    fun insertArticle()

    @Query("SELECT * FROM article_info")
    fun getArticles() : List<ArticleEntity>
}